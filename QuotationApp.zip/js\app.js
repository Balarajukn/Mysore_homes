/**
 * DHARE INFRA Quotation Generator - Core Application Script
 */

document.addEventListener('DOMContentLoaded', () => {

    // Initial State Structure
    let appState = {
        refNo: "DI/QUO/2026/042",
        date: new Date().toISOString().split('T')[0],
        validUntil: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        clientName: "Mr. Rajesh Sharma",
        clientPhone: "+91 98123 45678",
        clientEmail: "rajesh.sharma@example.com",
        siteAddress: "Villa 108, Prestige Green Meadows, Sarjapur Road, Bengaluru",
        gstEnabled: true,
        gstRate: 18,
        items: [],
        terms: DHARE_INFRA_PRESETS.terms.slice(),
        bankDetails: { ...DHARE_INFRA_PRESETS.bankDetails },
        presetTemplates: DHARE_INFRA_PRESETS.presetItemTemplates.map(p => ({ ...p }))
    };

    // DOM Element References - Editor Inputs
    const inpRefNo = document.getElementById('inp-ref-no');
    const inpDate = document.getElementById('inp-date');
    const inpValidUntil = document.getElementById('inp-valid-until');
    const inpClientName = document.getElementById('inp-client-name');
    const inpClientPhone = document.getElementById('inp-client-phone');
    const inpClientEmail = document.getElementById('inp-client-email');
    const inpSiteAddress = document.getElementById('inp-site-address');
    const inpGstEnable = document.getElementById('inp-gst-enable');
    const inpGstRate = document.getElementById('inp-gst-rate');
    const gstRateWrapper = document.getElementById('gst-rate-wrapper');
    const editorItemsBody = document.getElementById('editor-items-body');
    const presetsChipsContainer = document.getElementById('presets-chips-container');
    const wordsPreviewText = document.getElementById('words-preview-text');
    const inpTerms = document.getElementById('inp-terms');
    const inpBankName = document.getElementById('inp-bank-name');
    const inpAccName = document.getElementById('inp-acc-name');
    const inpAccNo = document.getElementById('inp-acc-no');
    const inpIfsc = document.getElementById('inp-ifsc');
    const inpBranch = document.getElementById('inp-branch');
    const inpUpi = document.getElementById('inp-upi');

    // Preset Manager Modal Elements
    const btnManagePresets = document.getElementById('btn-manage-presets');
    const modalPresetsManager = document.getElementById('modal-presets-manager');
    const btnClosePresetModal = document.getElementById('btn-close-preset-modal');
    const btnDonePresetModal = document.getElementById('btn-done-preset-modal');
    const presetsManagerList = document.getElementById('presets-manager-list');
    const inpNewPresetLabel = document.getElementById('inp-new-preset-label');
    const inpNewPresetLength = document.getElementById('inp-new-preset-length');
    const inpNewPresetHeight = document.getElementById('inp-new-preset-height');
    const inpNewPresetRate = document.getElementById('inp-new-preset-rate');
    const inpNewPresetDesc = document.getElementById('inp-new-preset-desc');
    const btnSaveNewPreset = document.getElementById('btn-save-new-preset');
    const btnRestoreDefaultPresets = document.getElementById('btn-restore-default-presets');

    // Action Buttons
    const btnInstallApp = document.getElementById('btn-install-app');
    const btnAddRow = document.getElementById('btn-add-row');
    const btnPrint = document.getElementById('btn-print');
    const btnLoadSample = document.getElementById('btn-load-sample');
    const btnReset = document.getElementById('btn-reset');
    const btnExportJson = document.getElementById('btn-export-json');
    const fileImportJson = document.getElementById('file-import-json');

    // PWA Install Prompt Listener
    let deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        if (btnInstallApp) {
            btnInstallApp.style.display = 'inline-flex';
        }
    });

    if (btnInstallApp) {
        btnInstallApp.addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                if (outcome === 'accepted') {
                    btnInstallApp.style.display = 'none';
                }
                deferredPrompt = null;
            } else {
                alert("To install on your mobile device:\n\n• Android Chrome: Tap the 3 dots (⋮) menu -> 'Install App' or 'Add to Home screen'\n• iPhone Safari: Tap the Share button (⎋) -> 'Add to Home Screen'");
            }
        });
    }

    window.addEventListener('appinstalled', () => {
        if (btnInstallApp) {
            btnInstallApp.style.display = 'none';
        }
        deferredPrompt = null;
    });

    // DOM Element References - Live Preview Elements
    const pvRefNo = document.getElementById('pv-ref-no');
    const pvDate = document.getElementById('pv-date');
    const pvValidUntil = document.getElementById('pv-valid-until');
    const pvClientName = document.getElementById('pv-client-name');
    const pvClientPhone = document.getElementById('pv-client-phone');
    const pvClientAddress = document.getElementById('pv-site-address');
    const pvItemsBody = document.getElementById('pv-items-body');
    const pvWordsText = document.getElementById('pv-words-text');
    const pvSubtotal = document.getElementById('pv-subtotal');
    const pvGstRow = document.getElementById('pv-gst-row');
    const pvGstRateText = document.getElementById('pv-gst-rate-text');
    const pvGstAmount = document.getElementById('pv-gst-amount');
    const pvGrandTotal = document.getElementById('pv-grand-total');
    const pvTermsList = document.getElementById('pv-terms-list');
    const pvAccName = document.getElementById('pv-acc-name');
    const pvBankName = document.getElementById('pv-bank-name');
    const pvAccNo = document.getElementById('pv-acc-no');
    const pvIfsc = document.getElementById('pv-ifsc');
    const pvBranch = document.getElementById('pv-branch');
    const pvUpi = document.getElementById('pv-upi');

    /**
     * Helper: Format Currency to Indian Rupee (₹)
     */
    function formatCurrency(val) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            maximumFractionDigits: 2
        }).format(val || 0);
    }

    /**
     * Helper: Format Date string (YYYY-MM-DD -> DD-MM-YYYY)
     */
    function formatDate(dateStr) {
        if (!dateStr) return '';
        const parts = dateStr.split('-');
        if (parts.length === 3) {
            return `${parts[2]}-${parts[1]}-${parts[0]}`;
        }
        return dateStr;
    }

    /**
     * Save / Load Preset Templates from LocalStorage
     */
    function savePresetTemplates() {
        try {
            localStorage.setItem('dhare_infra_custom_presets', JSON.stringify(appState.presetTemplates));
        } catch (e) {}
    }

    function loadPresetTemplates() {
        try {
            const saved = localStorage.getItem('dhare_infra_custom_presets');
            if (saved) {
                appState.presetTemplates = JSON.parse(saved);
                return;
            }
        } catch (e) {}
        appState.presetTemplates = DHARE_INFRA_PRESETS.presetItemTemplates.map(p => ({ ...p }));
    }

    /**
     * Initialize & Render Preset Quick Chips
     */
    function renderPresetChips() {
        presetsChipsContainer.innerHTML = '';
        const templates = appState.presetTemplates || DHARE_INFRA_PRESETS.presetItemTemplates;
        templates.forEach((template) => {
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'preset-chip';
            chip.innerHTML = `<i class="fa-solid fa-plus-circle"></i> ${escapeHtml(template.label)}`;
            chip.addEventListener('click', () => {
                addItemRow({
                    description: template.description,
                    length: template.length,
                    height: template.height,
                    rate: template.rate
                });
                renderApp();
            });
            presetsChipsContainer.appendChild(chip);
        });
    }

    /**
     * Render Editable Preset Templates in Manager Modal
     */
    function renderPresetManagerList() {
        if (!presetsManagerList) return;
        presetsManagerList.innerHTML = '';
        const templates = appState.presetTemplates || [];
        
        if (templates.length === 0) {
            presetsManagerList.innerHTML = `
                <p style="font-size:0.8rem; color:#94a3b8; text-align:center; padding:12px;">
                    No preset templates available. Add one below or click 'Restore Default Presets'.
                </p>
            `;
            return;
        }

        templates.forEach((item, index) => {
            const row = document.createElement('div');
            row.className = 'preset-item-row';
            row.innerHTML = `
                <div style="flex: 1; display: flex; flex-direction: column; gap: 0.35rem;">
                    <div style="display: flex; gap: 0.4rem; flex-wrap: wrap;">
                        <input type="text" class="form-control inp-p-label" value="${escapeHtml(item.label)}" placeholder="Chip Label" style="flex: 1.5; min-width: 120px; font-weight: 600;">
                        <input type="number" step="0.1" class="form-control inp-p-len" value="${item.length}" placeholder="Len" style="width: 65px;" title="Length (ft)">
                        <input type="number" step="0.1" class="form-control inp-p-hgt" value="${item.height}" placeholder="Hgt" style="width: 65px;" title="Height (ft)">
                        <input type="number" step="1" class="form-control inp-p-rate" value="${item.rate}" placeholder="Rate" style="width: 80px;" title="Rate (₹)">
                    </div>
                    <input type="text" class="form-control inp-p-desc" value="${escapeHtml(item.description)}" placeholder="Work / Material Description">
                </div>
                <button type="button" class="btn btn-danger btn-sm btn-del-preset" style="padding: 0.4rem 0.6rem;" title="Delete Preset">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            `;

            const pLabel = row.querySelector('.inp-p-label');
            const pLen = row.querySelector('.inp-p-len');
            const pHgt = row.querySelector('.inp-p-hgt');
            const pRate = row.querySelector('.inp-p-rate');
            const pDesc = row.querySelector('.inp-p-desc');
            const pDel = row.querySelector('.btn-del-preset');

            const onEdit = () => {
                item.label = pLabel.value;
                item.length = parseFloat(pLen.value) || 0;
                item.height = parseFloat(pHgt.value) || 0;
                item.rate = parseFloat(pRate.value) || 0;
                item.description = pDesc.value;
                savePresetTemplates();
                renderPresetChips();
            };

            pLabel.addEventListener('input', onEdit);
            pLen.addEventListener('input', onEdit);
            pHgt.addEventListener('input', onEdit);
            pRate.addEventListener('input', onEdit);
            pDesc.addEventListener('input', onEdit);

            pDel.addEventListener('click', () => {
                appState.presetTemplates.splice(index, 1);
                savePresetTemplates();
                renderPresetManagerList();
                renderPresetChips();
            });

            presetsManagerList.appendChild(row);
        });
    }

    /**
     * Add a new item to the items list
     */
    function addItemRow(initialData = {}) {
        const newItem = {
            id: 'item_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
            description: initialData.description || '',
            length: initialData.length !== undefined ? initialData.length : 1,
            height: initialData.height !== undefined ? initialData.height : 1,
            rate: initialData.rate !== undefined ? initialData.rate : 0
        };
        appState.items.push(newItem);
        renderEditorItems();
        renderApp();
    }

    /**
     * Remove item by ID
     */
    function removeItemRow(id) {
        appState.items = appState.items.filter(item => item.id !== id);
        renderEditorItems();
        renderApp();
    }

    /**
     * Render items table inside Editor
     */
    function renderEditorItems() {
        editorItemsBody.innerHTML = '';
        appState.items.forEach((item, index) => {
            const tr = document.createElement('tr');
            tr.dataset.id = item.id;

            const area = (parseFloat(item.length) || 0) * (parseFloat(item.height) || 0);
            const total = area * (parseFloat(item.rate) || 0);

            tr.innerHTML = `
                <td class="col-sno">${index + 1}</td>
                <td class="col-desc">
                    <input type="text" class="form-control inp-item-desc" value="${escapeHtml(item.description)}" placeholder="Work details...">
                </td>
                <td class="col-num">
                    <input type="number" step="0.1" min="0" class="form-control inp-item-length" value="${item.length}">
                </td>
                <td class="col-num">
                    <input type="number" step="0.1" min="0" class="form-control inp-item-height" value="${item.height}">
                </td>
                <td class="col-calc item-area-calc">${area.toFixed(2)}</td>
                <td class="col-num">
                    <input type="number" step="1" min="0" class="form-control inp-item-rate" value="${item.rate}">
                </td>
                <td class="col-calc item-total-calc">${formatCurrency(total)}</td>
                <td class="col-action">
                    <button type="button" class="btn btn-danger btn-sm btn-del-item" title="Delete Row">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            `;

            // Attach input event listeners for real-time reactivity
            const inpDesc = tr.querySelector('.inp-item-desc');
            const inpLength = tr.querySelector('.inp-item-length');
            const inpHeight = tr.querySelector('.inp-item-height');
            const inpRate = tr.querySelector('.inp-item-rate');
            const btnDel = tr.querySelector('.btn-del-item');

            inpDesc.addEventListener('input', (e) => {
                item.description = e.target.value;
                renderLivePreview();
                saveLocalState();
            });

            const onDimChange = () => {
                item.length = parseFloat(inpLength.value) || 0;
                item.height = parseFloat(inpHeight.value) || 0;
                item.rate = parseFloat(inpRate.value) || 0;

                const newArea = item.length * item.height;
                const newTotal = newArea * item.rate;

                tr.querySelector('.item-area-calc').textContent = newArea.toFixed(2);
                tr.querySelector('.item-total-calc').textContent = formatCurrency(newTotal);

                renderApp();
            };

            inpLength.addEventListener('input', onDimChange);
            inpHeight.addEventListener('input', onDimChange);
            inpRate.addEventListener('input', onDimChange);

            btnDel.addEventListener('click', () => {
                removeItemRow(item.id);
            });

            editorItemsBody.appendChild(tr);
        });
    }

    /**
     * Escape HTML string helper
     */
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/>/g, "&gt;")
                  .replace(/"/g, "&quot;")
                  .replace(/'/g, "&#039;");
    }

    /**
     * Formats item description so that the item name (before ' - ' or ':')
     * is automatically converted to UPPERCASE and wrapped in <strong>...</strong> (BOLD),
     * followed by the rest of the content description.
     */
    function formatFormattedDescription(descStr) {
        if (!descStr || !descStr.trim()) return '—';
        const str = descStr.trim();
        
        let separator = null;
        if (str.includes(' - ')) {
            separator = ' - ';
        } else if (str.includes(' : ')) {
            separator = ' : ';
        } else if (str.includes(': ')) {
            separator = ': ';
        }

        if (separator) {
            const parts = str.split(separator);
            const itemName = parts[0].trim().toUpperCase();
            const restContent = parts.slice(1).join(separator).trim();
            if (restContent) {
                return `<strong style="font-weight: 700; color: #0f172a;">${escapeHtml(itemName)}</strong> - ${escapeHtml(restContent)}`;
            } else {
                return `<strong style="font-weight: 700; color: #0f172a;">${escapeHtml(itemName)}</strong>`;
            }
        } else {
            return `<strong style="font-weight: 700; color: #0f172a;">${escapeHtml(str.toUpperCase())}</strong>`;
        }
    }

    /**
     * Update Form Field Values from appState
     */
    function populateFormFields() {
        inpRefNo.value = appState.refNo || '';
        inpDate.value = appState.date || '';
        inpValidUntil.value = appState.validUntil || '';
        inpClientName.value = appState.clientName || '';
        inpClientPhone.value = appState.clientPhone || '';
        inpClientEmail.value = appState.clientEmail || '';
        inpSiteAddress.value = appState.siteAddress || '';
        
        const isGstOn = appState.gstEnabled !== false;
        if (inpGstEnable) inpGstEnable.checked = isGstOn;
        if (inpGstRate) inpGstRate.disabled = !isGstOn;
        if (gstRateWrapper) gstRateWrapper.style.opacity = isGstOn ? '1' : '0.4';

        inpGstRate.value = appState.gstRate !== undefined ? appState.gstRate : 18;

        inpTerms.value = (appState.terms || []).join('\n');
        
        inpBankName.value = appState.bankDetails.bankName || '';
        inpAccName.value = appState.bankDetails.accountName || '';
        inpAccNo.value = appState.bankDetails.accountNo || '';
        inpIfsc.value = appState.bankDetails.ifscCode || '';
        inpBranch.value = appState.bankDetails.branch || '';
        inpUpi.value = appState.bankDetails.upiId || '';

        renderEditorItems();
    }

    /**
     * Main Render & Calculation Function for Live Preview
     */
    function renderLivePreview() {
        // Metadata Updates
        pvRefNo.textContent = appState.refNo || '—';
        pvDate.textContent = formatDate(appState.date) || '—';
        pvValidUntil.textContent = formatDate(appState.validUntil) || '—';
        pvClientName.textContent = appState.clientName || '—';
        pvClientPhone.textContent = appState.clientPhone || '—';
        pvClientAddress.textContent = appState.siteAddress || '—';

        // Render Printed Items Table
        pvItemsBody.innerHTML = '';
        let subtotal = 0;

        if (appState.items.length === 0) {
            pvItemsBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center" style="color: #94a3b8; padding: 15px;">
                        No quotation items added yet. Use the editor panel to add work details.
                    </td>
                </tr>
            `;
        } else {
            appState.items.forEach((item, index) => {
                const area = (parseFloat(item.length) || 0) * (parseFloat(item.height) || 0);
                const total = area * (parseFloat(item.rate) || 0);
                subtotal += total;

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="text-center font-semibold">${index + 1}</td>
                    <td>${formatFormattedDescription(item.description)}</td>
                    <td class="text-center">${item.length || 0}</td>
                    <td class="text-center">${item.height || 0}</td>
                    <td class="text-right font-semibold">${area.toFixed(2)}</td>
                    <td class="text-right">${formatCurrency(item.rate)}</td>
                    <td class="text-right font-semibold">${formatCurrency(total)}</td>
                `;
                pvItemsBody.appendChild(tr);
            });
        }

        // Financial Calculations
        const isGstOn = appState.gstEnabled !== false;
        const effectiveGstRate = isGstOn ? (parseFloat(appState.gstRate) || 0) : 0;
        const gstAmount = subtotal * (effectiveGstRate / 100);
        const grandTotal = subtotal + gstAmount;

        pvSubtotal.textContent = formatCurrency(subtotal);

        if (isGstOn && effectiveGstRate > 0) {
            pvGstRow.style.display = 'table-row';
            pvGstRateText.textContent = effectiveGstRate;
            pvGstAmount.textContent = formatCurrency(gstAmount);
        } else {
            pvGstRow.style.display = 'none';
        }

        pvGrandTotal.textContent = formatCurrency(grandTotal);

        // Indian Numbering System Words Conversion
        const words = numberToIndianWords(grandTotal);
        pvWordsText.textContent = words;
        wordsPreviewText.textContent = words;

        // Render Terms List
        pvTermsList.innerHTML = '';
        (appState.terms || []).forEach(term => {
            if (term.trim()) {
                const li = document.createElement('li');
                li.textContent = term.trim();
                pvTermsList.appendChild(li);
            }
        });

        // Company Contact Info Sync
        const pvCompanyAddress = document.getElementById('pv-company-address');
        const pvCompanyPhone = document.getElementById('pv-company-phone');
        const pvCompanyEmail = document.getElementById('pv-company-email');
        const pvCompanyGstin = document.getElementById('pv-company-gstin');
        const pvCompanyTagline = document.getElementById('pv-company-tagline');
        if (pvCompanyTagline) pvCompanyTagline.textContent = DHARE_INFRA_PRESETS.company.tagline;
        if (pvCompanyAddress) pvCompanyAddress.textContent = DHARE_INFRA_PRESETS.company.address;
        if (pvCompanyPhone) pvCompanyPhone.textContent = DHARE_INFRA_PRESETS.company.phone;
        if (pvCompanyEmail) pvCompanyEmail.textContent = DHARE_INFRA_PRESETS.company.email;
        if (pvCompanyGstin) pvCompanyGstin.textContent = DHARE_INFRA_PRESETS.company.gstin;

        // Bank Details
        pvBankName.textContent = appState.bankDetails.bankName || '—';
        pvAccName.textContent = appState.bankDetails.accountName || '—';
        pvAccNo.textContent = appState.bankDetails.accountNo || '—';
        pvIfsc.textContent = appState.bankDetails.ifscCode || '—';
        pvBranch.textContent = appState.bankDetails.branch || '—';
        pvUpi.textContent = appState.bankDetails.upiId || '—';
    }

    /**
     * Global App Render Call
     */
    function renderApp() {
        renderLivePreview();
        saveLocalState();
    }

    /**
     * LocalStorage Auto-save
     */
    function saveLocalState() {
        try {
            localStorage.setItem('dhare_infra_quote_state', JSON.stringify(appState));
        } catch (e) {
            console.warn('LocalStorage save error', e);
        }
    }

    /**
     * LocalStorage Load
     */
    function loadLocalState() {
        try {
            const saved = localStorage.getItem('dhare_infra_quote_state');
            if (saved) {
                appState = JSON.parse(saved);
                return true;
            }
        } catch (e) {
            console.warn('LocalStorage load error', e);
        }
        return false;
    }

    /**
     * Attach Event Listeners to Static Form Inputs
     */
    function attachFormListeners() {
        inpRefNo.addEventListener('input', (e) => { appState.refNo = e.target.value; renderApp(); });
        inpDate.addEventListener('change', (e) => { appState.date = e.target.value; renderApp(); });
        inpValidUntil.addEventListener('change', (e) => { appState.validUntil = e.target.value; renderApp(); });
        inpClientName.addEventListener('input', (e) => { appState.clientName = e.target.value; renderApp(); });
        inpClientPhone.addEventListener('input', (e) => { appState.clientPhone = e.target.value; renderApp(); });
        inpClientEmail.addEventListener('input', (e) => { appState.clientEmail = e.target.value; renderApp(); });
        inpSiteAddress.addEventListener('input', (e) => { appState.siteAddress = e.target.value; renderApp(); });
        if (inpGstEnable) {
            inpGstEnable.addEventListener('change', (e) => {
                appState.gstEnabled = e.target.checked;
                if (inpGstRate) inpGstRate.disabled = !appState.gstEnabled;
                if (gstRateWrapper) gstRateWrapper.style.opacity = appState.gstEnabled ? '1' : '0.4';
                renderApp();
            });
        }
        inpGstRate.addEventListener('change', (e) => { appState.gstRate = parseFloat(e.target.value) || 0; renderApp(); });

        inpTerms.addEventListener('input', (e) => {
            appState.terms = e.target.value.split('\n');
            renderApp();
        });

        inpBankName.addEventListener('input', (e) => { appState.bankDetails.bankName = e.target.value; renderApp(); });
        inpAccName.addEventListener('input', (e) => { appState.bankDetails.accountName = e.target.value; renderApp(); });
        inpAccNo.addEventListener('input', (e) => { appState.bankDetails.accountNo = e.target.value; renderApp(); });
        inpIfsc.addEventListener('input', (e) => { appState.bankDetails.ifscCode = e.target.value; renderApp(); });
        inpBranch.addEventListener('input', (e) => { appState.bankDetails.branch = e.target.value; renderApp(); });
        inpUpi.addEventListener('input', (e) => { appState.bankDetails.upiId = e.target.value; renderApp(); });

        // Add Row Button
        btnAddRow.addEventListener('click', () => {
            addItemRow();
        });

        // Print / Save PDF Button
        btnPrint.addEventListener('click', () => {
            window.print();
        });

        // Load Sample Quote
        btnLoadSample.addEventListener('click', () => {
            loadSampleData();
        });

        // Reset Form Button
        btnReset.addEventListener('click', () => {
            if (confirm("Are you sure you want to clear and reset the quotation form?")) {
                appState.items = [];
                appState.refNo = "DI/QUO/" + new Date().getFullYear() + "/" + Math.floor(100 + Math.random() * 900);
                appState.clientName = "";
                appState.clientPhone = "";
                appState.clientEmail = "";
                appState.siteAddress = "";
                appState.terms = DHARE_INFRA_PRESETS.terms.slice();
                appState.bankDetails = { ...DHARE_INFRA_PRESETS.bankDetails };
                populateFormFields();
                renderApp();
            }
        });

        // Export JSON Draft
        btnExportJson.addEventListener('click', () => {
            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appState, null, 2));
            const downloadAnchor = document.createElement('a');
            downloadAnchor.setAttribute("href", dataStr);
            const fileName = `DHARE_INFRA_Quotation_${(appState.refNo || 'draft').replace(/[\/\\:]/g, '_')}.json`;
            downloadAnchor.setAttribute("download", fileName);
            document.body.appendChild(downloadAnchor);
            downloadAnchor.click();
            downloadAnchor.remove();
        });

        // Import JSON Draft
        fileImportJson.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const imported = JSON.parse(event.target.result);
                    appState = imported;
                    populateFormFields();
                    renderApp();
                    alert("Quotation draft imported successfully!");
                } catch (err) {
                    alert("Invalid JSON file format.");
                }
            };
            reader.readAsText(file);
        });

        // Preset Manager Modal Listeners
        if (btnManagePresets) {
            btnManagePresets.addEventListener('click', () => {
                renderPresetManagerList();
                if (modalPresetsManager) modalPresetsManager.style.display = 'flex';
            });
        }
        if (btnClosePresetModal) {
            btnClosePresetModal.addEventListener('click', () => {
                if (modalPresetsManager) modalPresetsManager.style.display = 'none';
            });
        }
        if (btnDonePresetModal) {
            btnDonePresetModal.addEventListener('click', () => {
                if (modalPresetsManager) modalPresetsManager.style.display = 'none';
            });
        }
        if (btnSaveNewPreset) {
            btnSaveNewPreset.addEventListener('click', () => {
                const label = inpNewPresetLabel.value.trim();
                const desc = inpNewPresetDesc.value.trim();
                const len = parseFloat(inpNewPresetLength.value) || 0;
                const hgt = parseFloat(inpNewPresetHeight.value) || 0;
                const rate = parseFloat(inpNewPresetRate.value) || 0;

                if (!label || !desc) {
                    alert("Please enter both a Chip Label and Work Description for the preset.");
                    return;
                }

                appState.presetTemplates.push({
                    label,
                    description: desc,
                    length: len,
                    height: hgt,
                    rate
                });

                savePresetTemplates();
                renderPresetManagerList();
                renderPresetChips();

                inpNewPresetLabel.value = '';
                inpNewPresetDesc.value = '';
            });
        }
        if (btnRestoreDefaultPresets) {
            btnRestoreDefaultPresets.addEventListener('click', () => {
                if (confirm("Restore default DHARE INFRA preset templates?")) {
                    appState.presetTemplates = DHARE_INFRA_PRESETS.presetItemTemplates.map(p => ({ ...p }));
                    savePresetTemplates();
                    renderPresetManagerList();
                    renderPresetChips();
                }
            });
        }
    }

    /**
     * Load Sample DHARE INFRA Project Data
     */
    function loadSampleData() {
        const sample = DHARE_INFRA_PRESETS.sampleQuotation;
        appState.refNo = sample.refNo;
        appState.date = sample.date;
        appState.validUntil = sample.validUntil;
        appState.clientName = sample.clientName;
        appState.clientPhone = sample.clientPhone;
        appState.clientEmail = sample.clientEmail;
        appState.siteAddress = sample.siteAddress;
        appState.gstRate = sample.gstRate;
        appState.items = sample.items.map(item => ({
            id: 'item_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
            ...item
        }));
        appState.terms = DHARE_INFRA_PRESETS.terms.slice();
        appState.bankDetails = { ...DHARE_INFRA_PRESETS.bankDetails };

        populateFormFields();
        renderApp();
    }

    // App Initialization Flow
    loadPresetTemplates();
    renderPresetChips();
    attachFormListeners();

    const loadedFromStorage = loadLocalState();
    if (!loadedFromStorage || !appState.items || appState.items.length === 0) {
        loadSampleData();
    } else {
        if (appState.bankDetails && (appState.bankDetails.accountNo === '50200088991122' || appState.bankDetails.upiId !== '9845748491@hdfc' || !appState.bankDetails.branch || appState.bankDetails.branch.includes('Bengaluru') || appState.bankDetails.branch.includes('Ramakrishna Nagar'))) {
            appState.bankDetails = { ...DHARE_INFRA_PRESETS.bankDetails };
        }
        populateFormFields();
        renderApp();
    }

});
