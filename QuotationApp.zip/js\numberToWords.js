/**
 * Converts a numeric amount to Indian Numbering System words.
 * Examples:
 * 125000 -> "Rupees One Lakh Twenty-Five Thousand Only"
 * 3450.50 -> "Rupees Three Thousand Four Hundred Fifty and Fifty Paise Only"
 */
function numberToIndianWords(amount) {
    if (isNaN(amount) || amount === null || amount === undefined) {
        return "Rupees Zero Only";
    }

    const num = Math.abs(parseFloat(amount));
    if (num === 0) return "Rupees Zero Only";

    const parts = num.toFixed(2).split('.');
    let rupees = parseInt(parts[0], 10);
    const paise = parseInt(parts[1], 10);

    const singleDigits = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
    const teenDigits = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    const tensDigits = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

    function convertTwoDigits(n) {
        if (n < 10) return singleDigits[n];
        if (n >= 10 && n < 20) return teenDigits[n - 10];
        const tenPart = tensDigits[Math.floor(n / 10)];
        const singlePart = singleDigits[n % 10];
        return singlePart ? `${tenPart}-${singlePart}` : tenPart;
    }

    function convertThreeDigits(n) {
        const hundredPart = Math.floor(n / 100);
        const remainder = n % 100;
        let str = "";
        if (hundredPart > 0) {
            str += singleDigits[hundredPart] + " Hundred";
        }
        if (remainder > 0) {
            if (str !== "") str += " ";
            str += convertTwoDigits(remainder);
        }
        return str;
    }

    let words = "";

    // Crores (10,00,00,000)
    const crores = Math.floor(rupees / 10000000);
    rupees %= 10000000;

    // Lakhs (1,00,000)
    const lakhs = Math.floor(rupees / 100000);
    rupees %= 100000;

    // Thousands (1,000)
    const thousands = Math.floor(rupees / 1000);
    rupees %= 1000;

    // Remaining hundreds (100)
    const remaining = rupees;

    if (crores > 0) {
        words += (convertTwoDigits(crores) || convertThreeDigits(crores)) + " Crore ";
    }
    if (lakhs > 0) {
        words += convertTwoDigits(lakhs) + " Lakh ";
    }
    if (thousands > 0) {
        words += convertTwoDigits(thousands) + " Thousand ";
    }
    if (remaining > 0) {
        words += convertThreeDigits(remaining);
    }

    words = words.trim();
    let result = words ? `Rupees ${words}` : "Rupees Zero";

    if (paise > 0) {
        const paiseWords = convertTwoDigits(paise);
        result += ` and ${paiseWords} Paise`;
    }

    result += " Only";
    return result;
}

// Export for module or browser window use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { numberToIndianWords };
}
