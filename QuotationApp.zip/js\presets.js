/**
 * DHARE INFRA Default Profiles, Terms, Bank Details and Sample Quotation Data
 */
const DHARE_INFRA_PRESETS = {
    company: {
        name: "DHARE INFRA",
        tagline: "Construction | Interior's | Renovation",
        address: "No. 1593, Vishwamanava Double Road, \"B\" Cross, E&F Block, Ramakrishna Nagar, Near Andholana circle, Mysuru - 570022",
        phone: "+91 98457 48491",
        email: "dhareinfra@gmail.com",
        gstin: "29CFNPB7826P2ZL"
    },
    bankDetails: {
        accountName: "DHARE INFRA",
        bankName: "HDFC Bank",
        accountNo: "50200107634926",
        ifscCode: "HDFC0000065",
        branch: "Saraswatipuram, Mysore",
        upiId: "9845748491@hdfc"
    },
    terms: [
        "50% Advance payment required upon order confirmation to initiate site work and material procurement.",
        "40% Payment on material delivery at site and installation stage.",
        "Balance 10% Payment upon final walkthrough and project handover.",
        "Quotation validity: 15 days from the date of issue.",
        "Any additional scope, structural alteration, or material upgrade will be quoted and billed separately."
    ],
    sampleQuotation: {
        refNo: "DI/QUO/2026/042",
        date: new Date().toISOString().split('T')[0],
        validUntil: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        clientName: "Mr. Rajesh Sharma",
        clientPhone: "+91 98123 45678",
        clientEmail: "rajesh.sharma@example.com",
        siteAddress: "Villa 108, Prestige Green Meadows, Sarjapur Road, Bengaluru",
        gstEnabled: true,
        gstRate: 18,
        items: [
            {
                description: "FALSE CEILING WORK - Heavy-duty Gypsum Board with GI Metal Framing, Cove Lighting Channels & Jointing Compound",
                length: 20,
                height: 15,
                rate: 110
            },
            {
                description: "MODULAR KITCHEN CABINETS - BWP Marine Plywood with 1mm High-Gloss Acrylic Laminate & Soft-Close Tandem Boxes",
                length: 14,
                height: 8,
                rate: 1450
            },
            {
                description: "VITRIFIED TILE FLOORING - Premium 4x2 ft Glazed Vitrified Tiles with Epoxy Grouting & Skirting",
                length: 25,
                height: 18,
                rate: 165
            },
            {
                description: "MASTER BEDROOM WARDROBE - Full Height 18mm Commercial Ply with Inner White Laminate & External Suede Finish",
                length: 12,
                height: 9.5,
                rate: 1250
            },
            {
                description: "INTERIOR WALL PAINTING - Asian Paints Royale Luxury Emulsion (2 Coats) with Acrylic Putty & Primer Base",
                length: 35,
                height: 10,
                rate: 45
            }
        ]
    },
    presetItemTemplates: [
        { label: "False Ceiling (Gypsum)", length: 15, height: 12, rate: 110, description: "FALSE CEILING WORK - Gypsum board with cove channel lighting groove" },
        { label: "Modular Kitchen", length: 12, height: 7.5, rate: 1450, description: "MODULAR KITCHEN CABINETS - BWP Marine Ply with Acrylic Finish" },
        { label: "Wardrobe (Full Height)", length: 10, height: 9, rate: 1200, description: "FULL HEIGHT WARDROBE - Bedroom wardrobe with soft-close fittings" },
        { label: "Vitrified Flooring 4x2", length: 20, height: 15, rate: 165, description: "VITRIFIED TILE FLOORING - 4x2 ft tiles with epoxy grout" },
        { label: "Royale Emulsion Paint", length: 30, height: 10, rate: 45, description: "INTERIOR PAINTING - Asian Paints Royale Emulsion premium 2 coats" },
        { label: "Electrical Rewiring", length: 1, height: 1, rate: 25000, description: "ELECTRICAL WORK - Complete rewiring and modular switch installation package" },
        { label: "TV Unit (Console)", length: 8, height: 6, rate: 1100, description: "TV UNIT CONSOLE - Designer TV unit with wall panel and floating cabinet" }
    ]
};
